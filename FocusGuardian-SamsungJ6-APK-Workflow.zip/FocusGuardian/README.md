# Focus Guardian
A lightweight Android app blocker for study sessions.

### Install
Open this project in Android Studio, let Gradle sync, connect the Samsung Galaxy J6, and Run the app.

Then:
1. Open Focus Guardian.
2. Tap ENABLE APP BLOCKING.
3. Enable Focus Guardian under Android Accessibility.
4. Select Instagram/YouTube/etc.
5. Enter study duration.
6. Tap START FOCUS.

The app uses Android AccessibilityService only to detect the apps the user explicitly selected for blocking.
