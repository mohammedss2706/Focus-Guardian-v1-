package com.focusguardian

import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class BlockActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("focus", MODE_PRIVATE) }
    private val messages=listOf(
        "You came home with a dream. Don't trade it for another reel.",
        "Your future is being built in the small choices you make today.",
        "One more reel feels small. One focused hour can change your future.",
        "Discipline is choosing what you want most over what you want now."
    )
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root=LinearLayout(this).apply {
            orientation=LinearLayout.VERTICAL; gravity=Gravity.CENTER
            setPadding(32,32,32,32); setBackgroundColor(Color.rgb(10,14,18))
        }
        root.addView(TextView(this).apply { text="PAUSE"; textSize=38f; gravity=Gravity.CENTER; setTextColor(Color.WHITE) })
        root.addView(TextView(this).apply {
            text=messages[(System.currentTimeMillis()/10000%messages.size).toInt()]
            textSize=22f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0,30,0,30)
        })
        root.addView(TextView(this).apply {
            text="“And that there is not for man except that [good] for which he strives.”\n\n— Qur'an 53:39"
            textSize=18f; gravity=Gravity.CENTER; setTextColor(Color.LTGRAY)
        })
        val remaining=TextView(this).apply { textSize=17f; gravity=Gravity.CENTER; setTextColor(Color.WHITE); setPadding(0,24,0,24) }
        root.addView(remaining)
        root.addView(Button(this).apply { text="BACK TO STUDY"; setOnClickListener { finish() } })
        root.addView(Button(this).apply {
            text="5 MINUTE EMERGENCY ACCESS"
            setOnClickListener {
                prefs.edit().putLong("emergency_until",System.currentTimeMillis()+300000L).apply()
                finish()
            }
        })
        setContentView(root)
        val end=prefs.getLong("end",0L)
        object: android.os.CountDownTimer((end-System.currentTimeMillis()).coerceAtLeast(0),1000) {
            override fun onTick(ms:Long) {
                val s=ms/1000
                remaining.text="Focus remaining: %02d:%02d:%02d".format(s/3600,(s%3600)/60,s%60)
            }
            override fun onFinish(){ remaining.text="Focus session complete. Well done."; finish() }
        }.start()
    }
}
