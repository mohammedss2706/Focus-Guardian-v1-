package com.focusguardian

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

class FocusAccessibilityService : AccessibilityService() {
    private val prefs by lazy { getSharedPreferences("focus", MODE_PRIVATE) }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType != AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) return
        val pkg=event.packageName?.toString() ?: return
        if (pkg==packageName || pkg=="com.android.systemui") return
        val end=prefs.getLong("end",0L)
        val emergency=prefs.getLong("emergency_until",0L)
        if (end<=System.currentTimeMillis() || emergency>System.currentTimeMillis()) return
        if (prefs.getBoolean(pkg,false)) {
            startActivity(Intent(this,BlockActivity::class.java).apply {
                addFlags(Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP)
            })
        }
    }
    override fun onInterrupt() {}
}
