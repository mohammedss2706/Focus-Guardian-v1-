package com.focusguardian

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.graphics.Color
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("focus", MODE_PRIVATE) }
    private val apps = listOf(
        "com.instagram.android" to "Instagram",
        "com.google.android.youtube" to "YouTube",
        "com.facebook.katana" to "Facebook",
        "com.twitter.android" to "X / Twitter",
        "com.snapchat.android" to "Snapchat",
        "com.reddit.frontpage" to "Reddit"
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(28,24,28,24)
            setBackgroundColor(Color.rgb(16,20,24))
        }
        fun tv(text:String, size:Float): TextView = TextView(this).apply {
            this.text=text; textSize=size; setTextColor(Color.WHITE)
            setPadding(0,8,0,8)
        }
        root.addView(tv("Focus Guardian",30f))
        root.addView(tv("Protect your study time. Take back your attention.",16f))
        root.addView(tv("Focus duration (minutes)",16f))
        val duration=EditText(this).apply {
            setText("120"); hint="Example: 120"; inputType=2
            setTextColor(Color.WHITE); setHintTextColor(Color.GRAY)
        }
        root.addView(duration)
        root.addView(tv("Apps to block",18f))
        apps.forEach { (pkg,name) ->
            root.addView(CheckBox(this).apply {
                text=name; textSize=16f; setTextColor(Color.WHITE)
                isChecked=prefs.getBoolean(pkg, pkg.contains("instagram") || pkg.contains("youtube"))
                setOnCheckedChangeListener { _, checked -> prefs.edit().putBoolean(pkg,checked).apply() }
            })
        }
        root.addView(Button(this).apply {
            text="START FOCUS"
            setOnClickListener {
                val mins=duration.text.toString().toLongOrNull()?.coerceIn(1,1440) ?: 120
                prefs.edit().putLong("end",System.currentTimeMillis()+mins*60000L).apply()
                Toast.makeText(this@MainActivity,"Focus mode started",Toast.LENGTH_SHORT).show()
            }
        })
        root.addView(Button(this).apply {
            text="ENABLE APP BLOCKING"
            setOnClickListener { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        })
        root.addView(Button(this).apply {
            text="STOP FOCUS"
            setOnClickListener { prefs.edit().putLong("end",0L).apply(); Toast.makeText(this@MainActivity,"Focus stopped",Toast.LENGTH_SHORT).show() }
        })
        root.addView(tv("Enable Focus Guardian in Accessibility settings before starting. Then choose your distracting apps.",13f))
        setContentView(root)
    }
}
