# Build the APK without Android Studio

## Easiest method: GitHub Actions

1. Create a free GitHub account if you do not already have one.
2. Create a new repository, for example `FocusGuardian`.
3. Upload the contents of this project ZIP to that repository.
   - Upload the folders/files inside the ZIP, not the ZIP itself.
4. Commit them to the `main` branch.
5. GitHub will automatically run `.github/workflows/build-apk.yml`.
6. Open the repository's **Actions** tab.
7. Open the **Build Focus Guardian APK** workflow run.
8. At the bottom, under **Artifacts**, download `FocusGuardian-debug-apk`.
9. Extract the downloaded artifact. You will find `app-debug.apk`.

## Install on Samsung Galaxy J6

1. Transfer `app-debug.apk` to the phone.
2. Open the APK.
3. If Android asks, allow installation from that source.
4. Install Focus Guardian.
5. Open it.
6. Tap **ENABLE APP BLOCKING**.
7. Enable Focus Guardian under Accessibility.
8. Select Instagram/YouTube/etc.
9. Choose your study duration.
10. Tap **START FOCUS**.

## Important

This is a debug APK intended for personal use. It is not a Play Store release.

Because the blocker uses Android AccessibilityService, Samsung/Android may show an accessibility warning. The service is used to detect the user-selected apps and display the focus screen.

If you change the source code later, push the changes to GitHub and the workflow will build a fresh APK.
